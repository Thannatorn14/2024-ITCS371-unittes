# python-calculator

This is a very simple calculator program for learning how to write unit tests in Python. It contains a Calculator class (*calculator.py*) which perform 4 mathematic operations: add, subtract, multiply, and divide. You have to add unit test cases to test them in the file *test_calculator.py*. 